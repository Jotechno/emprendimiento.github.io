

const {Router} = require('express')


const route = Router()
//se define despues de crear el controllador
//importar metodos del controlador
const{productoGet, productoPost, productoPut, productoDelete}=require('../controllers/producto')
route.get('/', productoGet)

route.post('/',productoPost )

route.put('/',productoPut )

route.delete('/',productoDelete )

module.exports = route


